<footer id="mastfooter" class="boostify-site-footer">
	<div class="boostify-footer-inner">
		<?php the_content(); ?>
	</div>
</footer>
