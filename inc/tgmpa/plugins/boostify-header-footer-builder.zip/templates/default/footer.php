<?php
	do_action( 'boostify_hf_get_footer' );
?>
</div>
<?php
do_action( 'boostify_hf_footer' );
wp_footer();
?>
</body>
</html>
